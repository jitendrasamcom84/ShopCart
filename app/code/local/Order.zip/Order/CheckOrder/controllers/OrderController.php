<?php

class Order_CheckOrder_OrderController extends Mage_Core_Controller_Front_Action{


  /**
  * Index action
  *
  * @access public
  * @return void
  */
  public function indexAction() {

    echo "index"; 
    var_dump($this->getRequest()->getParams());
  // var_dump($this->getRequest()->getParams());
  // echo $order = Mage::app()->getRequest()->getParam('order');

  }

  /**
  * Order action
  *
  * @access public
  * @return void
  */
  public function orderAction() {

    echo "order"; 
    var_dump($this->getRequest()->getParams());
  // var_dump($this->getRequest()->getParams());
  // echo $order = Mage::app()->getRequest()->getParam('order');

  }

  /**
  * Other action
  *
  * @access public
  * @return void
  */
  public function otherAction() {

    echo "Other"; 
    echo "<hr/>";
    var_dump($this->getRequest()->getParams());
  // echo $order = Mage::app()->getRequest()->getParam('order');

  }

  
}

// class Order_CheckOrder_OrderController extends Mage_Core_Controller_Varien_Router_Abstract{
//   public function initControllerRouters($observer){

//   }
// }
?>